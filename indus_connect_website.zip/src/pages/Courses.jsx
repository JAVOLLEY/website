import React from "react";
const courseList = [
  { title: "Caregiving", duration: "2 months", image: "/images/caregiving.jpg" },
  { title: "Driving", duration: "1 month", image: "/images/driving.jpg" },
  { title: "Hairdressing", duration: "3 months", image: "/images/hairdressing.jpg" },
  { title: "Computer Packages", duration: "2 months", image: "/images/computers.jpg" },
  { title: "Solar PV Installation", duration: "2 months", image: "/images/solar.jpg" },
  { title: "Electrical Installation", duration: "3 months", image: "/images/electrical.jpg" },
  { title: "Plumbing", duration: "2 months", image: "/images/plumbing.jpg" },
  { title: "CCTV Installation", duration: "1 month", image: "/images/cctv.jpg" }
];

function Courses() {
  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold mb-4">Our Short Courses</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {courseList.map((course, idx) => (
          <div key={idx} className="rounded shadow p-4 bg-white">
            <img src={course.image} alt={course.title} className="w-full h-40 object-cover rounded" />
            <h2 className="text-xl font-semibold mt-2">{course.title}</h2>
            <p>Duration: {course.duration}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Courses;