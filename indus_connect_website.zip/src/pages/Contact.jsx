import React from "react";

function Contact() {
  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-2">Contact Us</h1>
      <p>Phone: 0736176616</p>
      <p>Email: skillupkenya1@gmail.com</p>
      <p>Location: Nairobi, Kenya</p>
    </div>
  );
}

export default Contact;